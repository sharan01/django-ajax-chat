from django.contrib import admin
from djangoChat.models import Message


admin.site.register(Message)
# optional ordering