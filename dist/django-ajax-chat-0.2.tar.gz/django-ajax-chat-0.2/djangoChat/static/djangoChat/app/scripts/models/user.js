define(['backbone'],function(){
	return Backbone.Model.extend({

	});
});